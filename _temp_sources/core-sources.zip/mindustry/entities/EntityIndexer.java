package mindustry.entities;

import mindustry.gen.*;

public interface EntityIndexer{
    void change(Entityc t, int index);
}
