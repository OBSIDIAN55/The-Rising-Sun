package mindustry.entities.comp;

import mindustry.annotations.Annotations.*;
import mindustry.gen.*;

@Component
class OwnerComp{
    Entityc owner;
}
