package mindustry.io.versions;

import mindustry.io.*;

/** Adds patches in content header. */
public class Save11 extends SaveVersion{

    public Save11(){
        super(11);
    }
}
