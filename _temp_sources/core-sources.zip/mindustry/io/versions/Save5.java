package mindustry.io.versions;

/** Uses the legacy readWorldEntities function without entity IDs. */
public class Save5 extends LegacySaveVersion2{

    public Save5(){
        super(5);
    }
}
