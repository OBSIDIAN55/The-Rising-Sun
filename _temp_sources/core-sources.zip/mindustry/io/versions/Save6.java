package mindustry.io.versions;

/** This version does not read custom chunk data. */
public class Save6 extends LegacyRegionSaveVersion{

    public Save6(){
        super(6);
    }
}
