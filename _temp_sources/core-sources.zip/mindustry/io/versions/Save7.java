package mindustry.io.versions;

public class Save7 extends ShortChunkSaveVersion{

    public Save7(){
        super(7);
    }
}
