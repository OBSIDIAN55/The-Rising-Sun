package mindustry.io.versions;

import mindustry.io.*;

public class Save7 extends SaveVersion{

    public Save7(){
        super(7);
    }
}
