package mindustry.logic;

public enum CutsceneAction{
    pan,
    zoom,
    stop;

    public static final CutsceneAction[] all = values();
}
