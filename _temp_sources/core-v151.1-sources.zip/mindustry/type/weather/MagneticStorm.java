package mindustry.type.weather;

import mindustry.type.*;

//TODO
public class MagneticStorm extends Weather{

    public MagneticStorm(String name){
        super(name);
    }
}
