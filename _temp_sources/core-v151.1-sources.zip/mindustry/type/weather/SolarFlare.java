package mindustry.type.weather;

import mindustry.type.*;

//TODO
public class SolarFlare extends Weather{

    public SolarFlare(String name){
        super(name);
    }
}
