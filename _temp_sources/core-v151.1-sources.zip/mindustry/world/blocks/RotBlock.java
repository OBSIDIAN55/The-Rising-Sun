package mindustry.world.blocks;

/** Any block that has 360-degree rotation */
public interface RotBlock{
    float buildRotation();
}
