package mindustry.world.blocks;

public interface UnitTetherBlock{
    void spawned(int id);
}
