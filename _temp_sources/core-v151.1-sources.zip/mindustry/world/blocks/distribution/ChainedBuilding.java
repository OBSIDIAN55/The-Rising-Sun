package mindustry.world.blocks.distribution;

import mindustry.gen.*;

public interface ChainedBuilding{
    Building next();
}