package mindustry.world.blocks.heat;

public interface HeatConsumer{
    float[] sideHeat();
    float heatRequirement();
}
